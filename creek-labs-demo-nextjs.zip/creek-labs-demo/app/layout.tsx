import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = {title:'Creek Labs | Your Business, Beautifully Connected',description:'Explore the Creek Labs interactive business operating system demo: CRM, sales pipeline, tasks, and workflow automation.'};
export default function RootLayout({children}:{children:React.ReactNode}) {return <html lang="en"><body>{children}</body></html>}
