# Creek Labs — Public Interactive Demo

A deployable Next.js demo of Creek Labs CRM Studio for professional-services startups. Includes an interactive dashboard, editable customer CRM, four-stage pipeline, follow-up tasks, configurable workflow simulations, and integration concepts.

## Run locally

Requires Node.js 20 or newer.

```bash
npm install
npm run dev
```

Open http://localhost:3000.

## Deploy with Vercel

1. Create a new GitHub repository (for example `creek-labs-demo`).
2. Upload the **contents of this folder** to the root of that repository, including `package.json` and `app/`.
3. Sign in to https://vercel.com with GitHub.
4. Select **Add New → Project** and import the repository.
5. Keep Framework Preset as **Next.js**. The root directory should be the repository root.
6. Select **Deploy**. Vercel will provide a URL similar to `your-project.vercel.app` after a successful build.
7. Visit the URL and test the dashboard, CRM editing, pipeline, tasks, and automation simulation.
8. Optional: In Vercel Project Settings → Domains, add a domain you own and follow the displayed DNS instructions.

## Demo limitations

- All customer records are fictional and reside in browser memory only.
- Changes are **not persisted** and reset on page refresh.
- No real OAuth connections, AI inference, database, authentication, or multi-tenant data isolation.
- Do not input real client or sensitive data.
- Workflow events are simulated; they do not access Gmail, Slack, Notion, GitHub, or HubSpot.
- The sample dashboard values are illustrative, not verified business metrics.

## Next steps toward production

- Supabase or another database with authenticated, isolated workspaces and row-level security.
- Validated server-side APIs, roles, audit logging, and rate limits.
- OAuth connectors with minimal scopes, encryption, sync jobs, retries, and explicit write approval.
- AI-assisted suggestions with evaluation, consent, and human approval for consequential actions.
- Production observability, backups, privacy policy, and terms.

## Security

No secrets are needed for the demo. Never commit API keys or OAuth client secrets to GitHub.
